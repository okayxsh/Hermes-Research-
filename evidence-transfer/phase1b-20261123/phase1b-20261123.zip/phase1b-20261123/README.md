# RQ1 Phase 1B evidence transfer package

**Preparation evidence only.** Not an approved manifest, roster, label set or scientific result. Nothing here was
generated, normalised or re-serialised: every file under `evidence/` is the original byte sequence of its source.

## 1. Contents

| Package path | Bytes | SHA-256 | Kind | Original |
|---|---|---|---|---|
| `evidence/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913-final-a/acquisition-check-report.json` | 2881 | `c82d54137fcfcef478b13a061309271adf5501ea045f0c41d0f3ecb3045b4667` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913-final-a/acquisition-check-report.json |
| `evidence/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913-final-a/check-plan.json` | 535 | `831e0490e95533334715cf89327c879c7d9764af1eedcbc3eeb113b5aa32db7f` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913-final-a/check-plan.json |
| `evidence/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913-gemma-a/check-plan.json` | 1006 | `37822ac34bf733f6d6990b513fe2e2618ad8adf6ac40e9d4ee8e28be26a5a241` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913-gemma-a/check-plan.json |
| `evidence/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913-gemma-b/acquisition-check-report.json` | 4875 | `5fdf01821bfdadd481d43bc88d993a3cf7f8e645863ff2e2a8dabf25ebca3a39` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913-gemma-b/acquisition-check-report.json |
| `evidence/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913-gemma-b/check-plan.json` | 1006 | `63a8f60702508ede4ab125ec439dcf9efdc5a1bcda209ab46dfd2cf20fcf1906` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913-gemma-b/check-plan.json |
| `evidence/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913a/acquisition-check-report.json` | 4112 | `4943763c79aacbc683d95092a52e768ce8bfb8d8d1bfe14263e0b0ba67104bdf` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913a/acquisition-check-report.json |
| `evidence/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913a/check-plan.json` | 948 | `791c510f1c340698469184944448cbf47171769f8a7c5763528e887d7afbd596` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913a/check-plan.json |
| `evidence/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913b/acquisition-check-report.json` | 4117 | `98c2d105cc767dc7f02896eeb15e1c85a89cbf8f7e9992f1a7859fa07856c2ed` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913b/acquisition-check-report.json |
| `evidence/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913b/check-plan.json` | 948 | `a2e8cf41cd55705208e5630bf306ea480400fd056eacbc8b13c4cbaf9309e48d` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913b/check-plan.json |
| `evidence/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913c/acquisition-check-report.json` | 7057 | `94481bc13bf9a5aded7a1924dbd2186a145d3e08bc285b9869babb97a4cce2b4` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913c/acquisition-check-report.json |
| `evidence/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913c/check-plan.json` | 1685 | `24e5850fb5f0c7ac464f68b984ba71c3646a60c8866038e382e71f0f9c935790` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/acquisition-check/prelaunch-acquisition-check-20260913c/check-plan.json |
| `evidence/artifacts/prelaunch/acquisition-extension-check/prelaunch-acquisition-extension-check-20260914-a/acquisition-extension-check-report.json` | 4261 | `bafbf2ef0e570456d93ac1ccdcbed12698427da9135c61b757aa2073290fb11e` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/acquisition-extension-check/prelaunch-acquisition-extension-check-20260914-a/acquisition-extension-check-report.json |
| `evidence/artifacts/prelaunch/acquisition-extension-check/prelaunch-acquisition-extension-check-20260914-a/check-plan.json` | 804 | `74d8acff5ef3dea50ee23a4758c81056de4564cd74e1943771b1823aa4c55c3e` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/acquisition-extension-check/prelaunch-acquisition-extension-check-20260914-a/check-plan.json |
| `evidence/artifacts/prelaunch/evaluation-check/prelaunch-evaluation-check-20260914-a/check-plan.json` | 4205 | `fe52bce0d640ae8f4d958cdb92b18366a34e5c93d113c8a71405531a6de65a87` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/evaluation-check/prelaunch-evaluation-check-20260914-a/check-plan.json |
| `evidence/artifacts/prelaunch/evaluation-check/prelaunch-evaluation-check-20260914-a/evaluation-check-report.json` | 2796 | `7fe81c33071539999be493602a817774b6d0131eb5839e3af96674e4c7dff196` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/evaluation-check/prelaunch-evaluation-check-20260914-a/evaluation-check-report.json |
| `evidence/artifacts/prelaunch/harness-audit/20260913T060935Z/expert-replay-report.json` | 22580 | `02bda3371e74a77baa383a191a00fa01885ee028944c601884b1fb61e4c4fe34` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/harness-audit/20260913T060935Z/expert-replay-report.json |
| `evidence/artifacts/prelaunch/harness-audit/20260913T060935Z/gemma-b-expert-divergence.json` | 35027 | `514762ea7020410c95a41a8a7d0cce88f35b61d4d7c02fc44e4810869c98e0c8` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/harness-audit/20260913T060935Z/gemma-b-expert-divergence.json |
| `evidence/artifacts/prelaunch/prelaunch-6873cce26de74e6cb0770cf9d1c9ff22/run-manifest.json` | 397 | `977dfa0c8c844e9a8462936d3f4768ce8145f2736ef957ff1de710ff3be8cff5` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/prelaunch-6873cce26de74e6cb0770cf9d1c9ff22/run-manifest.json |
| `evidence/artifacts/prelaunch/prelaunch-750213c493fc418fb1d909d52d960215/run-manifest.json` | 397 | `07a0051bfd2ab0a2d27b9618600dfaa36d41383ec1e7bd164b67cd59145effb3` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/prelaunch-750213c493fc418fb1d909d52d960215/run-manifest.json |
| `evidence/artifacts/prelaunch/prelaunch-a718b4e4d9644b01aa4861e6905cd587/pilot-report.json` | 2607 | `fe4201c2508eee472d6d01ad4ec1be2c1302d3aa18103bd25b2086c74f4022ab` | committed_repository_file | experiment/rq1-scientific-phase1/artifacts/prelaunch/prelaunch-a718b4e4d9644b01aa4861e6905cd587/pilot-report.json |
| `evidence/artifacts/prelaunch/prelaunch-d5c2cb5df2584bc787a1056c4712ff18/run-manifest.json` | 574 | `e5c0fdf9f0119dcb40e17856bef1da1d620628642bf177d72caa21a1698b1569` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/prelaunch-d5c2cb5df2584bc787a1056c4712ff18/run-manifest.json |
| `evidence/artifacts/prelaunch/prelaunch-df8a8b46e52140328cb5b6a827f0e8c7/run-manifest.json` | 574 | `59f2d1e6dea0fd304cce244786c7ec304dedd575f37f9a8c767926cda8a5734d` | prelaunch_run_record | archive member rq1-complete-experiment-final/repo/artifacts/prelaunch/prelaunch-df8a8b46e52140328cb5b6a827f0e8c7/run-manifest.json |
| `evidence/artifacts/task_manifests/frozen/acquisition-b64c383e0f335b90.json` | 1124904 | `d002ec6f73bc35a146ffbf1991416c048e2ef7a6cb668051e94348f5dd229219` | frozen_task_manifest | rq2-workspace/inputs/rq1-complete-experiment-final/repo/artifacts/task_manifests/frozen/acquisition-b64c383e0f335b90.json |
| `evidence/artifacts/task_manifests/frozen_evaluation/evaluation-amended-b83a2ecacba19992.json` | 57758 | `340f52ce660f703d9b98e1cf2a58ac195e2fe7c1c380f08b98d0419929bdb429` | frozen_task_manifest | rq2-workspace/inputs/rq1-complete-experiment-final/repo/artifacts/task_manifests/frozen_evaluation/evaluation-amended-b83a2ecacba19992.json |
| `evidence/artifacts/task_manifests/frozen_extension/acquisition-extension-4b9e3c8cda4dd809.json` | 1103716 | `860c66eedd7cd3c99761682b9d21df1d68cc5cd6c9c1fb8ccce194c1b0ded3a0` | frozen_task_manifest | rq2-workspace/inputs/rq1-complete-experiment-final/repo/artifacts/task_manifests/frozen_extension/acquisition-extension-4b9e3c8cda4dd809.json |
| `evidence/university-gpu/prospective/feasibility-200-candidate.json` | 47229 | `c60ead3eddcae90ffcac26fe0de55c12395fe8ee55bf782937ea6f5373590385` | committed_repository_file | experiment/rq1-scientific-phase1/university-gpu/prospective/feasibility-200-candidate.json |

Root files: `SHA256SUMS` (all other files), `package-inventory.json` (machine-readable provenance, checks, line endings),
`exposure-sources.phase1b-candidate.json` (SUGGESTED config, not applied), this `README.md`.

## 2. Provenance

- **Primary source archive:** `experiment/runs download results/rq1-final/03_Experiment_Archives/rq1-complete-experiment-final-20260914.tar.gz`
  SHA-256 `2caf1532043dbbf12b5384b0895d595fedcd2326d245af3bb47beb219a5c5d09` (matches its `.sha256` sidecar; archive dated 2026-09-14).
- **Independent archive for acquisition-180:** `experiment/runs download results/rq1-archive/rq1-acquisition-180-final-20260914.tar.gz`
  SHA-256 `442c18a40c18fc05e4c083595a2ea0ccf08f58061d2364768c379752e7e17f27` (matches sidecar); its copy of acquisition-180 is byte-identical.
- **Frozen manifests** were taken from the M0 read-only extraction (`rq2-workspace/inputs/rq1-complete-experiment-final/repo/...`).
  Each was cross-checked against the archive member stream and the M0 extraction record.
- **Prelaunch run records** are archive members of the same archive (repository paths preserved under `evidence/`).
- **Engineering candidate and October prelaunch report** are committed blobs at `275ae94a515304613c88943dccdc3e767f81ae75`
  (published on GitHub); bytes are the blob bytes, identical to a Linux checkout.

### Acquisition manifests

| Check | acquisition-180 | acquisition-extension-60 |
|---|---|---|
| manifest_type | "acquisition" | "acquisition-extension" |
| status | "frozen" | "frozen" |
| schema_version | 1 | 1 |
| split | "train" | "train" |
| alfworld_version | "0.4.2" | "0.4.2" |
| repository_commit | "8bd452e76120da21d721c6e894d1ce5af4912ca9" | "670627a9cd8800ce64e369a17263e3a3b0486dd1" |
| generated_at | "2026-09-13T09:31:09Z" | "2026-09-13T23:04:59Z" |
| approved_at | "2026-09-13T09:30:00Z" | "2026-09-13T23:03:43Z" |
| task_count | 180 | 60 |
| unique_task_ids | 180 | 60 |
| all_tasks_in_split | true | true |
| order_indices_contiguous | true | true |
| family_counts_match | true | true |
| embedded_manifest_sha256 | "717aa855c4947c2503aa019d014a474b77fbabcf0d45825de8d1aa41ab414ef2" | "5309f8be1cfc269539b7ea911f7495c8e34e84dc6ad0c57841960c1eb4e3e88a" |
| embedded_manifest_sha256_recomputed_matches | true | true |
| exclusion_reasons | {"missing_game_file": 2821, "not_selected": 3373} | {"missing_game_file": 2821, "not_selected": 3313, "selected_in_parent_acquisition_queue": 180} |

- acquisition-180 and extension-60 are disjoint: True;
  the extension's `selected_in_parent_acquisition_queue` exclusions equal the 180 parent tasks: True.

### CLI compatibility (branch `sci/rq1-phase1-task-oracle-prep` @ f71b4da)

The shipped template (`configs/scientific_prep/exposure-sources.template.json`) verifies against this package with
`--sources-base <package>/evidence`: no source is blocked; every resolved source matches its pinned raw SHA-256; 0 unresolvable
references; 0 undeclared exclusion reasons. The candidate config in this package also validates and does not block.

## 3. Exposure investigation (Task B)

| Record | Status | Finding |
|---|---|---|
| Kaggle ALFWorld smoke (`experiment/kaggle smoke tests/paper-check-v2 w results .ipynb`, sha256 `c18ad205a7c58f4e16c3b82718e61477d982eefcfbfe19d5dbf5c27bb6bffe7d`) | VERIFIED | `rq1.cli alfworld smoke-test --split valid_seen` started the first indexed task, stepped `admissible_actions[0]`, reset and aborted (code: `tasks[0]`, no model). Task: `valid_seen:look_at_obj_in_light-AlarmClock-None-DeskLamp-323/trial_T20190909_044715_250790`. The 140 other IDs in that notebook are an index listing only. Notebook not packaged (superseded by the evaluation check below). |
| Other Kaggle notebooks (`Hermes_RQ1_Kaggle_Temporary_Pilot.ipynb`, `..._Pilot_V2_RUN_ALL_SAFE.ipynb`) | UNRESOLVED | Saved without outputs; the temporary pilot ran `pilot run --mode fake`; no task identity recorded. |
| `Research stuff/Runs recorded here/first run in kaggle...md` | VERIFIED (no task) | hermes3:8b free-text prompt; no ALFWorld task. |
| Prelaunch acquisition checks 20260913a/b/c (hermes3:8b) and gemma-a/gemma-b/final-a (gemma4:12b); extension check 20260914-a (gemma4:12b) | VERIFIED | 18 distinct `train` tasks with model episode outcomes, none in the 240 acquisition manifests. Model per run from each run's `checkpoint.json` (archive members: 20260913a `e417a3ad...`, b `eb2475f9...`, c `d0ebb386...`, gemma-a `2bb1b794...`, gemma-b `b390e018...`, final-a `53053b52...`). |
| Prelaunch evaluation check 20260914-a (gemma4:12b, NoLib + Accum-18) | VERIFIED | Same valid_seen AlarmClock-323 task as the Kaggle smoke - now model-outcome EXPOSED. |
| Human-rater calibration (`quick-access/calibration/calibration-README.md`, docs `RETRIEVAL_RELEVANCE_RUBRIC.md`) | VERIFIED | Calibration items are the retrieval items of the valid_seen evaluation check above; no further task. |
| Prelaunch pilots 6873.../7502... (model not recorded) and d5c2.../df8a... (hermes3:8b), Sept 2026 | VERIFIED identities; model POSSIBLE for the first two | train Bowl-304 (already declared) + valid_seen AlarmClock-323. |
| Harness audit 20260913T060935Z | VERIFIED (no new task) | Expert replay of 6 acquisition-check train tasks + gemma-b divergence on 4 of them; packaged as corroborating provenance. |
| Evaluation preparation `f2a4e65fb054` (evaluation archive) | VERIFIED (no new exposure) | 255 valid_unseen IDs = 30 evaluated + 10 replaced + 94 route-screened (`not_selected`) + 121 `missing_game_file` listing entries. |
| RQ2 workspace (M4A/M4B smoke, pilot offline validation, M5 configs) | VERIFIED (no new exposure) | M4B used a synthetic fixture (`split: fixture`, `fake-pick-and-place-m4b`); all other references are the six engineering tasks. |
| University-side debugging / smoke / pilot / calibration logs after 2026-09-14 | UNRESOLVED | Not on the laptop. |

**Task IDs newly declared by the candidate config (19; not in the 240 acquisition, six engineering or October prelaunch sources):**

- `train:look_at_obj_in_light-AlarmClock-None-DeskLamp-309/trial_T20190908_062818_332126` - prelaunch-acquisition-check-20260913-gemma-a, prelaunch-acquisition-check-20260913-gemma-b, prelaunch-acquisition-check-20260913c
- `train:look_at_obj_in_light-AlarmClock-None-DeskLamp-323/trial_T20190909_044801_050688` - prelaunch-acquisition-check-20260913c
- `train:pick_and_place_simple-AlarmClock-None-Desk-310/trial_T20190908_002100_024659` - prelaunch-acquisition-check-20260913a, prelaunch-acquisition-check-20260913b
- `train:pick_and_place_simple-AlarmClock-None-Desk-310/trial_T20190908_002122_419694` - prelaunch-acquisition-check-20260913-gemma-a, prelaunch-acquisition-check-20260913-gemma-b, prelaunch-acquisition-check-20260913c, prelaunch-acquisition-extension-check-20260914-a
- `train:pick_and_place_simple-AlarmClock-None-Desk-314/trial_T20190908_185924_234584` - prelaunch-acquisition-check-20260913a, prelaunch-acquisition-check-20260913b
- `train:pick_and_place_simple-AlarmClock-None-DiningTable-329/trial_T20190909_011727_722798` - prelaunch-acquisition-check-20260913a, prelaunch-acquisition-check-20260913b
- `train:pick_and_place_simple-AlarmClock-None-DiningTable-329/trial_T20190909_011821_404731` - prelaunch-acquisition-check-20260913c
- `train:pick_and_place_simple-AlarmClock-None-Dresser-319/trial_T20190908_002730_200712` - prelaunch-acquisition-check-20260913a, prelaunch-acquisition-check-20260913b
- `train:pick_and_place_simple-AlarmClock-None-Shelf-310/trial_T20190907_151407_969856` - prelaunch-acquisition-check-20260913a, prelaunch-acquisition-check-20260913b
- `train:pick_and_place_simple-Book-None-ArmChair-209/trial_T20190909_091451_936328` - prelaunch-acquisition-check-20260913a, prelaunch-acquisition-check-20260913b
- `train:pick_clean_then_place_in_recep-Apple-None-DiningTable-19/trial_T20190907_230021_185388` - prelaunch-acquisition-check-20260913-gemma-a, prelaunch-acquisition-check-20260913-gemma-b, prelaunch-acquisition-check-20260913c
- `train:pick_clean_then_place_in_recep-Apple-None-DiningTable-4/trial_T20190918_193418_341390` - prelaunch-acquisition-check-20260913c
- `train:pick_cool_then_place_in_recep-Apple-None-DiningTable-16/trial_T20190909_075718_480016` - prelaunch-acquisition-check-20260913-gemma-a, prelaunch-acquisition-check-20260913-gemma-b, prelaunch-acquisition-check-20260913c
- `train:pick_cool_then_place_in_recep-Apple-None-GarbageCan-17/trial_T20190908_234248_429912` - prelaunch-acquisition-check-20260913c
- `train:pick_heat_then_place_in_recep-Apple-None-DiningTable-23/trial_T20190909_082402_950494` - prelaunch-acquisition-check-20260913-final-a, prelaunch-acquisition-check-20260913-gemma-a, prelaunch-acquisition-check-20260913-gemma-b, prelaunch-acquisition-check-20260913c, prelaunch-acquisition-extension-check-20260914-a
- `train:pick_heat_then_place_in_recep-Apple-None-Fridge-16/trial_T20190907_203354_811721` - prelaunch-acquisition-check-20260913c
- `train:pick_two_obj_and_place-AlarmClock-None-Desk-304/trial_T20190907_215326_695860` - prelaunch-acquisition-check-20260913-final-a, prelaunch-acquisition-check-20260913-gemma-a, prelaunch-acquisition-check-20260913-gemma-b, prelaunch-acquisition-check-20260913c
- `train:pick_two_obj_and_place-AlarmClock-None-Desk-307/trial_T20190907_013652_494441` - prelaunch-acquisition-check-20260913c
- `valid_seen:look_at_obj_in_light-AlarmClock-None-DeskLamp-323/trial_T20190909_044715_250790` - prelaunch-6873cce26de74e6cb0770cf9d1c9ff22, prelaunch-750213c493fc418fb1d909d52d960215, prelaunch-d5c2cb5df2584bc787a1056c4712ff18, prelaunch-df8a8b46e52140328cb5b6a827f0e8c7, prelaunch-evaluation-check-20260914-a

## 4. Verify on Linux

```sh
cd <package>                         # the directory containing SHA256SUMS
sha256sum -c SHA256SUMS              # every line must print OK
sha256sum -c SHA256SUMS | grep -vc ': OK$'   # must print 0
find evidence -type f | wc -l        # 26
# cross-check the frozen manifests against the template pins and the CLI (from the scientific clone):
cd ~/rq1-sci-phase1 && PYTHONPATH=src python3.11 -B -m rq1.scientific_prep exposure \
  --inventory "$OUT/inventory-inv-1/task-inventory.json" --sources <package>/exposure-sources.phase1b-candidate.json \
  --sources-base <package>/evidence --output-root "$OUT" --label exp-phase1b-1   # add --allow-provisional for a provisional screen
```

Line endings are recorded per file in `package-inventory.json` (`line_endings`); nothing was normalised. The CLI also
accepts a CRLF-only difference against a pinned hash and records it as `sha256_matched: lf_normalized`.

## 5. Provenance limitations

- The archive is a 2026-09-14 snapshot; records created later at the university are not covered (unresolved source kept).
- Two September prelaunch pilots (6873..., 7502...) do not record their model in their run files; they are declared
  POSSIBLY_EXPOSED (their tasks are EXPOSED through other records anyway).
- The original acquisition-180/240 runs and the 360-episode evaluation are covered by the frozen manifests, not by raw
  episode logs (not needed for exposure reconciliation; not packaged).
- The 79 -> 77 known-template list is still not authoritative (see the branch documentation).
- `exposure-sources.phase1b-candidate.json` is a suggestion: applying it, and which screening policy defines the
  confirmatory pool, are research decisions.
